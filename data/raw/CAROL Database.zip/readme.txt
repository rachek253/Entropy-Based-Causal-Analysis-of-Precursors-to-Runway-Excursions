Run time: 03/03/2026 04:58:31

Json query: {"ExportFormat":"data","ResultSetSize":500,"ResultSetOffset":4000,"TargetCollection":"cases","AndOr":"And","QueryGroups":[{"AndOr":"And","QueryRules":[{"RuleType":0,"Values":["300"],"Columns":["EventSequence.CICTTEventSOETitle"],"Operator":"is"}]}],"SortColumn":null,"SortDescending":true,"SessionId":162151}

Query text: [
	(CICTTEventSOETitle) is (300)
]

